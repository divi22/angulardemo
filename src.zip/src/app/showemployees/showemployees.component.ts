import { Component, OnInit } from '@angular/core';
import { UpdateEmployeeService } from '../update-employee.service';
import employeedata from '../../data/employeedata.json'
@Component({
  selector: 'app-showemployees',
  templateUrl: './showemployees.component.html',
  styleUrls: ['./showemployees.component.css']
})
export class ShowemployeesComponent implements OnInit {

  array=employeedata
  constructor(private service:UpdateEmployeeService) { }

  ngOnInit() {
  }
  
  DeleteData(i)
  {
    employeedata.splice(i,1)
  }
  public updatedata(i:number)
  {
    this.service.upsend(i);
  }
}
