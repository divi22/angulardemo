import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-angular',
  templateUrl: './angular.component.html',
  styleUrls: ['./angular.component.css']
})
export class AngularComponent implements OnInit {
  employee:any;

  constructor(private http:HttpClient) { }

  ngOnInit() {
    
    this.http.get("https://jsonplaceholder.typicode.com/posts").subscribe(Response=>this.employee=Response);
  }

}
