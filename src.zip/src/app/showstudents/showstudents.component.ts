import { Component, OnInit } from '@angular/core';
import { UpdateEmployeeService } from '../update-employee.service';
import employeedata from '../../data/employeedata.json';
@Component({
  selector: 'app-showstudents',
  templateUrl: './showstudents.component.html',
  styleUrls: ['./showstudents.component.css']
})
export class ShowstudentsComponent implements OnInit {

  array=employeedata
  constructor(private service:UpdateEmployeeService) { }

  ngOnInit() {
  }
  
  DeleteData(i)
  {
    employeedata.splice(i,1)
  }
  public updatedata(i:number)
  {
    this.service.upsend(i);
  }

}
