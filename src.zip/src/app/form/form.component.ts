import { Component, OnInit } from '@angular/core';
import {MathService} from '../math.service';
import employeedata from '../../data/employeedata.json'
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
employees=employeedata
i:number;
   id:number;
  name:string;
 salary:number;
 city:string;
  department:string;
  // flag:boolean=false;
 
   constructor(private service:MathService) { }
 
   ngOnInit() {
    
   }
   delete(i){
    
   this.employees.splice(i,1);
 
   }
   addEmployee(form){
     console.log(form.id,form.name,form.salary);
     this.addEmployee(form);
   }
  
   
//    display()
//    {
//      this.flag=true;
//      alert("Id:"+this.id+"Name:"+this.name+"Salary:"+this.salary+"Department:"+this.department);
//    }

// }
  }
