import { Component, OnInit } from '@angular/core';
import login from '../../data/login.json';
import {Router} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  

  constructor(private router:Router) { }

  ngOnInit() {
  }
 authenticate(form)
 {
    if(form.username==login.username && form.password==login.password )
    {
      alert("Authenticated");
      this.router.navigateByUrl('/angularcomponent');
    }
    else
    {
      alert("Please enter valid username and password")
      
    }



    



  }

}
